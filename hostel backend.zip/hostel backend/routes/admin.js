const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");

const dataPath = path.join(__dirname, "../adminData.json");

// Load all admins from JSON file
let admins = [];
if (fs.existsSync(dataPath)) {
  admins = JSON.parse(fs.readFileSync(dataPath, "utf8"));
}

// Create new admin
router.post("/create", (req, res) => {
  const { name, email, password } = req.body;

  const existingAdmin = admins.find(admin => admin.email === email);
  if (existingAdmin) {
    return res.status(400).json({ message: "Admin with this email already exists" });
  }

  const newAdmin = { name, email, password };
  admins.push(newAdmin);

  fs.writeFileSync(dataPath, JSON.stringify(admins, null, 2));

  res.status(201).json({ message: "Admin created successfully", admin: newAdmin });
});

// Update admin credentials
router.put("/update", (req, res) => {
  const { email, name, password } = req.body;

  const adminIndex = admins.findIndex(admin => admin.email === email);
  if (adminIndex === -1) {
    return res.status(404).json({ message: "Admin not found" });
  }

  if (name) admins[adminIndex].name = name;
  if (password) admins[adminIndex].password = password;

  fs.writeFileSync(dataPath, JSON.stringify(admins, null, 2));

  res.status(200).json({ message: "Admin updated successfully", admin: admins[adminIndex] });
});

// Get all admins
router.get("/all", (req, res) => {
  res.json(admins);
});

// Get single admin by email
router.get("/profile/:email", (req, res) => {
  const admin = admins.find(a => a.email === req.params.email);
  if (!admin) return res.status(404).json({ message: "Admin not found" });
  res.json(admin);
});

module.exports = router;