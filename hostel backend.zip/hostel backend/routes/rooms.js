const express = require("express");
const router = express.Router();

let rooms = [
  { id: 1, number: "101", booked: true },
  { id: 2, number: "102", booked: false },
  { id: 3, number: "103", booked: true },
  { id: 4, number: "104", booked: false }
];

router.get("/booked", (req, res) => {
  const bookedRooms = rooms.filter(room => room.booked);
  res.json(bookedRooms);
});

router.get("/available", (req, res) => {
  const availableRooms = rooms.filter(room => !room.booked);
  res.json(availableRooms);
});

module.exports = router;