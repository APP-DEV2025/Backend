const express = require("express");
const app = express();
const port = 3000;

app.use(express.json()); // parse JSON requests

// Routes
const adminRoutes = require("./routes/admin");
const roomRoutes = require("./routes/rooms"); // keep your rooms.js code

app.use("/admin", adminRoutes);
app.use("/rooms", roomRoutes);

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
}); 